import { StatusBar } from "expo-status-bar";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  FlatList,
  TouchableOpacity,
} from "react-native";
import React, { useState } from "react";

export default function ToDoList({ task }) {
  return (
    <View style={styles.container}>
      <ScrollView>
        <TouchableOpacity>
          <FlatList
            keyExtractor={(item) => item.task_id}
            data={task}
            renderItem={({ item }) => (
              <Text style={styles.complete}>{item.task_name}</Text>
            )}
          />
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff",
  },
  complete: {
    fontSize: 20,
    fontWeight: "bold",
    width: "100%",
    backgroundColor: "Black",
    flex: 1,
  },
  complete1: {
    fontSize: 20,
    fontWeight: "bold",
    width: "100%",
    backgroundColor: "gray",
    flex: 1,
  },
});
