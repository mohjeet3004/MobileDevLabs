import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import React, { useState } from "react";
import ToDoList from "./todoist";
import ToDoForm from "./TODO";

export default function App() {
  const [task, setTask] = useState([
    { task_name: "Do laundry", task_id: "1" },
    { task_name: "go to gym,", task_id: "1" },
  ]);

  return (
    <View style={styles.container}>
      <ToDoList task={task} />
      <ToDoForm setTask={setTask} />
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    marginTop: 50,
  },
});
